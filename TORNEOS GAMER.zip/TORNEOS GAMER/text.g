torneos-gamer/
├── css/
│   └── style.css
├── js/
│   ├── key.js        <- Clave secreta (ADMIN_KEY) y gestión de torneos en localStorage
│   └── main.js       <- Lógica de pagos, precios dinámicos y alertas a Telegram
├── img/
│   ├── freefire/
│   │   └── banner.jpg
│   └── codmobile/
│       └── banner.jpg
├── index.html        <- Página principal: Listado dinámico de torneos e imágenes
├── register.html     <- Pasarela de inscripción y reporte de pago automático
├── admin.html        <- Panel protegido con tu clave para publicar torneos
├── rules.html        <- Reglamento oficial de competición
└── leaderboard.html  <- Tabla de honor y muro de campeones
