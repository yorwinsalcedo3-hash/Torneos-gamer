/* ==========================================================================
   LÓGICA DE PAGOS, PRECIOS DINÁMICOS Y TELEGRAM
   ========================================================================== */
const TELEGRAM_CONFIG = {
  token: '8655279814:AAFdnMkqUve_wHeFFce5MUava4BNsTRbmI4',
  chatId: '5113013499'
};

document.addEventListener('DOMContentLoaded', () => {
  initPaymentSelector();
  initFormHandler();
});

// Control de visualización de métodos de pago
function initPaymentSelector() {
  const methodSelect = document.getElementById('payment-method');
  if (!methodSelect) return;

  const binanceDetails = document.getElementById('binance-details');
  const pagomovilDetails = document.getElementById('pagomovil-details');

  methodSelect.addEventListener('change', (e) => {
    const value = e.target.value;
    
    binanceDetails.classList.add('hidden');
    pagomovilDetails.classList.add('hidden');

    if (value === 'binance') {
      binanceDetails.classList.remove('hidden');
    } else if (value === 'pagomovil') {
      pagomovilDetails.classList.remove('hidden');
    }
  });
}

// Manejo del formulario y envío a Telegram
function initFormHandler() {
  const form = document.getElementById('registration-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerText = 'Enviando reporte...';

    const params = new URLSearchParams(window.location.search);
    const formData = {
      tournament: params.get('torneo') || 'Torneo General',
      price: params.get('precio') || 'A consultar',
      player: document.getElementById('player-name').value.trim(),
      gameId: document.getElementById('game-id').value.trim(),
      phone: document.getElementById('phone').value.trim(),
      paymentMethod: document.getElementById('payment-method').value,
      reference: document.getElementById('payment-ref').value.trim()
    };

    const message = buildTelegramMessage(formData);

    try {
      const response = await sendToTelegram(message);
      const data = await response.json();

      if (response.ok && data.ok) {
        alert('¡Pago reportado con éxito! Verificaremos tu transacción.');
        form.reset();
        document.getElementById('binance-details').classList.add('hidden');
        document.getElementById('pagomovil-details').classList.add('hidden');
      } else {
        throw new Error(data.description || 'Error de comunicación');
      }
    } catch (error) {
      alert('Ocurrió un error al enviar el reporte. Inténtalo nuevamente.');
      console.error(error);
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerText = 'Completar e Inscribirme';
    }
  });
}

function buildTelegramMessage(data) {
  return `💳 *¡NUEVO PAGO REPORTADO!* 💳\n\n` +
         `🏆 *Torneo:* ${data.tournament}\n` +
         `💰 *Monto:* ${data.price}\n` +
         `👤 *Jugador:* ${data.player}\n` +
         `🆔 *ID Juego:* ${data.gameId}\n` +
         `📱 *Teléfono:* ${data.phone}\n` +
         `💳 *Método:* ${data.paymentMethod.toUpperCase()}\n` +
         `🧾 *Referencia / TxID:* \`${data.reference}\`\n\n` +
         `⏳ *Estado:* Pendiente de verificación`;
}

async function sendToTelegram(text) {
  const url = `https://api.telegram.org/bot${TELEGRAM_CONFIG.token}/sendMessage`;
  return await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: TELEGRAM_CONFIG.chatId,
      text: text,
      parse_mode: 'Markdown'
    })
  });
}
