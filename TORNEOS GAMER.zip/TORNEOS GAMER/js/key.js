/* ==========================================================================
   CONFIGURACIÓN DE CLAVE (012225) Y GESTIÓN DE TORNEOS Y GANADORES
   ========================================================================== */
const ADMIN_KEY = "012225";

// Torneos iniciales vacíos
const torneosIniciales = [];
// Ganadores iniciales vacíos
const ganadoresIniciales = [];

// --- GESTIÓN DE TORNEOS ---
function obtenerTorneos() {
  const guardados = localStorage.getItem('lista_torneos');
  if (!guardados) {
    localStorage.setItem('lista_torneos', JSON.stringify(torneosIniciales));
    return torneosIniciales;
  }
  return JSON.parse(guardados);
}

function agregarTorneo(nombre, modo, precio, pozo, imagen, claveIngresada) {
  if (claveIngresada !== ADMIN_KEY) {
    alert("❌ Clave secreta incorrecta. Acceso denegado.");
    return false;
  }

  const torneos = obtenerTorneos();
  const nuevoTorneo = {
    id: Date.now(),
    nombre,
    modo,
    precio,
    pozo,
    imagen: imagen || "img/default-banner.jpg"
  };

  torneos.push(nuevoTorneo);
  localStorage.setItem('lista_torneos', JSON.stringify(torneos));
  alert("✅ ¡Torneo agregado con éxito!");
  return true;
}

// --- GESTIÓN DE GANADORES (TABLA DE HONOR) ---
function obtenerGanadores() {
  const guardados = localStorage.getItem('lista_ganadores');
  if (!guardados) {
    localStorage.setItem('lista_ganadores', JSON.stringify(ganadoresIniciales));
    return ganadoresIniciales;
  }
  return JSON.parse(guardados);
}

function agregarGanador(posicion, jugador, torneo, premio, claveIngresada) {
  if (claveIngresada !== ADMIN_KEY) {
    alert("❌ Clave secreta incorrecta. Acceso denegado.");
    return false;
  }

  const ganadores = obtenerGanadores();
  const nuevoGanador = {
    id: Date.now(),
    posicion,
    jugador,
    torneo,
    premio
  };

  ganadores.push(nuevoGanador);
  localStorage.setItem('lista_ganadores', JSON.stringify(ganadores));
  alert("🏆 ¡Ganador agregado al Muro de Honor!");
  return true;
}
